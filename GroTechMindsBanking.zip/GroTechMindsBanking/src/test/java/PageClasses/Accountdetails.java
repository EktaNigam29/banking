package PageClasses;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Accountdetails {
	
	WebDriver driver;
	public Accountdetails(WebDriver driver)
		{
			this.driver=driver;
			PageFactory.initElements(driver, this);
		}
	
	
	@FindBy(xpath="//a[text()='Account Detail']")
	WebElement accountDetails;
	
	
	@FindBy(xpath="//select[@id='collection_comp-m8swuunx']")
	WebElement selectName;
	
	@FindBy(xpath="//span[contains(text(), 'Login')]")
	WebElement loginButton;
	
	@FindBy(xpath="//span[text()='Deposit']")
	WebElement depositButton;
	
	@FindBy(xpath="//input[@id='input_comp-m8t00o79']")
	WebElement amount;
	
	@FindBy(xpath="(//span[text()='Deposit'])[2]")
			WebElement submitdeposit;
			
	
	public void click_on_Login()
	{
		accountDetails.click();
	}
	
	
	public void entername() throws AWTException 
	{
	//	JavascriptExecutor js = (JavascriptExecutor) driver;
	//	js.executeScript("arguments[0].value='Abhishek';", selectName);
		

		Robot sw = new Robot();
		sw.keyPress(KeyEvent.VK_DOWN);
		sw.keyPress(KeyEvent.VK_ENTER);
		 sw.delay(100);
		selectName.click();
		 sw.delay(100);
		sw.keyPress(KeyEvent.VK_DOWN);
		sw.keyPress(KeyEvent.VK_DOWN);
		sw.keyPress(KeyEvent.VK_ENTER);
		
	}
	
	public void submit_Login()
	{
		loginButton.click();
	}
	
	
	
	

}
