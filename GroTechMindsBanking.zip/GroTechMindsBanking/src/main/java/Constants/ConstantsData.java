package Constants;

public class ConstantsData {
	public final static String PropertyFilePath="src/main/java/Global.properties";
	public final static String ExcelPath="C:/Users/EKTA/Downloads/TestDataUrl16thApril.xlsx";
	

}
